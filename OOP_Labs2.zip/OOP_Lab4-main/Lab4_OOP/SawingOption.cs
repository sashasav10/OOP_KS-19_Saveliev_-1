﻿namespace Lab4_OOP
{
    public enum SawingOption
    {
        bar,
        unedgedBoard,
        edgedBoard,
        rail
    }
}
